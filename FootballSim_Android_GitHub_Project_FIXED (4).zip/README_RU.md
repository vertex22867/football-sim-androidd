# Football Sim — Android APK project

Это проект для сборки отдельного Android-приложения из вашего `index.html`.
Приложение открывает локальную копию игры во встроенном Android WebView, не перенаправляя в браузер.

## Как собрать APK через GitHub Actions (без установки Android Studio на телефон)

1. Создайте аккаунт на https://github.com/ (если его нет).
2. Нажмите `+` → `New repository`, назовите репозиторий `football-sim-android`, выберите `Public` или `Private`, нажмите `Create repository`.
3. Распакуйте архив проекта на компьютере. На странице репозитория нажмите `Add file` → `Upload files`.
4. Загрузите ВСЁ содержимое папки `android` в корень репозитория (в корне должны быть `settings.gradle`, `build.gradle`, `gradle.properties`, папка `app`).
5. Создайте папку `.github/workflows` в корне репозитория и добавьте файл `build-apk.yml` с содержимым ниже.
6. Перейдите на вкладку `Actions`, откройте запуск `Build Android APK`, дождитесь зелёной галочки.
7. Откройте завершённый запуск и внизу раздел `Artifacts` → скачайте `football-sim-debug-apk`.
8. Распакуйте скачанный ZIP на телефоне; внутри будет `app-debug.apk`. Нажмите APK, разрешите установку из этого источника, если Android попросит.

## Файл workflow

Создайте `.github/workflows/build-apk.yml` и вставьте:

```yaml
name: Build Android APK
on:
  workflow_dispatch:
  push:
    branches: [ main ]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Set up JDK
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4
      - name: Build debug APK
        run: gradle assembleDebug
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: football-sim-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
```

Важно: для этого способа Android-проект должен находиться в корне репозитория. Не загружайте папку `android` как вложенную папку `android`; загружайте её содержимое.
